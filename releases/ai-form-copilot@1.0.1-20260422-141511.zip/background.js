//#region src/shared/messages.ts
var e = /* @__PURE__ */ function(e) {
	return e.SCAN_FORM = "SCAN_FORM", e.SCAN_RESULT = "SCAN_RESULT", e.GENERATE_DATA = "GENERATE_DATA", e.GENERATE_RESULT = "GENERATE_RESULT", e.FILL_FORM = "FILL_FORM", e.FILL_RESULT = "FILL_RESULT", e.ERROR = "ERROR", e;
}({});
//#endregion
//#region src/shared/moonshot-kimi.ts
function t(e) {
	return (e ?? "").trim().replace(/\/$/, "").toLowerCase().endsWith("/anthropic");
}
//#endregion
//#region src/shared/ai-service.ts
function n(e) {
	return `你是一个智能表单测试数据生成器。请根据以下表单字段信息，生成合理的中文测试数据。

## 字段列表
${e.map((e) => {
		let t = [
			`字段ID: ${e.id}`,
			`标签: ${e.label}`,
			`类型: ${e.type}`
		];
		return e.required && t.push("必填: 是"), e.placeholder && t.push(`placeholder: ${e.placeholder}`), e.ruleHints && t.push(`校验/规则摘要(ruleHints，来自页面可见信息): ${e.ruleHints}`), e.validationError && t.push(`当前校验错误(上一轮填充后页面展示): ${e.validationError}`), e.extra && t.push(`表单项说明(extra): ${e.extra}`), e.options?.length && t.push(`可选值: ${e.options.join(", ")}`), e.constraints?.maxLength && t.push(`最大长度: ${e.constraints.maxLength}`), e.constraints?.min !== void 0 && t.push(`最小值: ${e.constraints.min}`), e.constraints?.max !== void 0 && t.push(`最大值: ${e.constraints.max}`), e.constraints?.pattern && t.push(`HTML pattern(正则): ${e.constraints.pattern}`), t.join(" | ");
	}).join("\n")}

## 生成规则
1. 根据字段标签语义生成合理数据（如"姓名"→中文姓名，"手机号"→11位手机号，"邮箱"→邮箱格式）
2. 对有可选值的字段（select/radio），必须从给定的可选值中选择一个
3. 必填字段必须有值
4. 遵守字段约束（最大长度、最小/最大值等）；若字段描述中含 **HTML pattern(正则)**，则填充值必须**整串匹配**该正则（仅使用 pattern 允许的字符，不要臆造未出现在字符类中的符号）；若存在「校验/规则摘要(ruleHints)」或「表单项说明(extra)」，请结合其理解校验要求（如：仅数字英文、「请输入字母或数字」= 只能含英文字母与数字无中文、最大字符数、范围、单位、小数位数），生成**能通过校验**的值；若错误/规则中出现「只能包含…」且枚举了允许字符（如字母、数字、&、=），则值**只能**由这些字符组成，**无中文、无未列出的符号**
5. 日期字段使用 YYYY-MM-DD 格式；**日期时间**（类型 date 但实际为 DateTimePicker、或标签含「执行时间」「触发时间」等）使用 **YYYY-MM-DD HH:mm:ss**，且日期部分须为 **用户本地意义的「今天」或更晚**（常见页面 disabledDate 会禁止昨天及以前；**不要**生成明显不可选的过去日）；**优先**使用 **本机「今天」起未来数日～约两周内**的日期——**越贴近当前日越容易与 disabledDate/disabledTime 对齐、填对概率越高**，不必刻意写很久以后或随意远年；若 extra 提到「需晚于名单包/计划执行时间」等，日期宜再留 1～2 天余量；若存在 disabledTime 语义（仅部分时段可选），时、分、秒宜选 **10:00～17:00** 等整点或常见工作时段，避免 0 点边界；antd@4 常见仅放开 **整点或半点**，**分钟建议只用 00 或 30**
6. 日期范围（类型为 daterange，如「开始-结束时间」/「有效时间」）必须返回英文逗号分隔的两段：**优先** YYYY-MM-DD HH:mm:ss,YYYY-MM-DD HH:mm:ss（开始早于结束；若业务用 RangePicker showTime 如 format='YYYY-MM-DD HH:mm:ss'，这是唯一能写入成功的格式）；仅当 placeholder 明确只有日期时可退化为 YYYY-MM-DD,YYYY-MM-DD。时分秒沿用规则 5：10–17 点、分钟仅 00 或 30
7. checkbox 类型如果有多个可选值，用逗号分隔；单个 checkbox 返回 "true"
8. **类型为 number（InputNumber）时：填充值必须是合法数字**（整数或小数），不能是中文、字母或带单位的文字；若 extra 或约束中给出取值范围/小数要求，必须遵守
9. 若存在「当前校验错误」，说明上一轮填充值未通过校验；你必须**针对该错误修正**生成新值（不要重复同样的错）
10. **类型为 select 且字段描述中未列出「可选值」**（常见于异步加载选项）时：该字段的 value **必须**为字符串 **random**（插件会在页面上打开下拉并随机点选一项）；不要省略该 key，也不要编造页面上可能不存在的选项文案
11. **类型为 time**（纯 TimePicker、无日期）时，值为 **HH:mm:ss**；宜选 **10:00～17:00**，分钟 **00 或 30**，便于贴合常见 disabledTime（与 date 类型的日期时间不同，不要带年月日）

## 返回格式
严格返回 JSON 对象，key 为字段ID，value 为填充值。只返回 JSON，不要其他内容。

示例：
{"field_0": "张三", "field_1": "13800138000", "field_2": "选项A"}`;
}
async function r(e, t, r) {
	let i = n(e), a = `${r}/v1/messages`, o = await fetch(a, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${t.apiKey}`,
			"anthropic-version": "2023-06-01"
		},
		body: JSON.stringify({
			model: t.model,
			max_tokens: 8192,
			system: "你是一个专业的测试数据生成助手，只返回 JSON 格式数据。",
			messages: [{
				role: "user",
				content: i
			}],
			temperature: .7
		})
	});
	if (!o.ok) {
		let e = await o.text();
		throw Error(`AI API 调用失败 (${o.status}): ${e}`);
	}
	let s = (await o.json()).content?.find((e) => e.type === "text")?.text;
	if (!s) throw Error("AI 返回内容为空");
	try {
		return JSON.parse(s);
	} catch {
		let e = s.match(/\{[\s\S]*\}/);
		if (e) return JSON.parse(e[0]);
		throw Error(`AI 返回的内容不是有效 JSON: ${s.slice(0, 200)}`);
	}
}
function i(e) {
	return e !== "minimax";
}
async function a(e, a) {
	let o = a.baseUrl?.replace(/\/$/, "") || "https://api.openai.com/v1";
	if (t(o)) return r(e, a, o);
	let s = {
		model: a.model,
		messages: [{
			role: "system",
			content: "你是一个专业的测试数据生成助手，只返回 JSON 格式数据。"
		}, {
			role: "user",
			content: n(e)
		}],
		temperature: .7
	};
	i(a.provider) && (s.response_format = { type: "json_object" });
	let c = await fetch(`${o}/chat/completions`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${a.apiKey}`
		},
		body: JSON.stringify(s)
	});
	if (!c.ok) {
		let e = await c.text();
		throw Error(`AI API 调用失败 (${c.status}): ${e}`);
	}
	let l = (await c.json()).choices?.[0]?.message?.content;
	if (!l) throw Error("AI 返回内容为空");
	try {
		return JSON.parse(l);
	} catch {
		let e = l.match(/\{[\s\S]*\}/);
		if (e) return JSON.parse(e[0]);
		throw Error(`AI 返回的内容不是有效 JSON: ${l.slice(0, 200)}`);
	}
}
//#endregion
//#region src/utils/mock-rules.ts
function o(e, t) {
	let n = t - e + 1, r = new Uint32Array(1);
	return crypto.getRandomValues(r), e + r[0] % n;
}
var s = (e) => e[o(0, e.length - 1)];
function c(e) {
	return `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
}
function l() {
	let e = /* @__PURE__ */ "赵.钱.孙.李.周.吴.郑.王.冯.陈.褚.卫.蒋.沈.韩.杨.朱.秦.尤.许.何.吕.施.张.孔.曹.严.华.金.魏.陶.姜.戚.谢.邹.苏.潘.葛.范.彭.鲁.韦.昌.马.苗.凤.花.方.俞.任.袁.柳.唐.罗.薛.汤.滕.殷.罗.毕.郝.邬.安.常.乐.于.时.傅.皮.齐.康.伍.余.元.卜.顾.孟.黄.穆.萧.尹.姚.邵.湛.汪.祁.毛.禹.狄.贝.臧.宣.丁.贺.邓.郁.单.杭.洪.龚".split("."), t = /* @__PURE__ */ "伟.芳.敏.静.丽.强.磊.洋.勇.艳.杰.娜.明.华.飞.平.刚.桂.英.辉.超.秀兰.霞.玲.军.波.涛.鑫.文.武.亮.宁.浩.琳.鹏.瑞.锋.欣.颖.雪.萍.博.思.雨.泽.凯.晨.婷.宇.佳.俊.悦.昊.天.睿.嘉.煜.航.阳.峰.林.松.翔.云.龙.虎.鸣.志.建.国.海.江.河.山.岩.柏.桐.枫.竹.梅".split(".");
	return s(e) + (o(1, 2) === 1 ? s(t) : s(t) + s(t));
}
function u() {
	return s(/* @__PURE__ */ "130.131.132.133.134.135.136.137.138.139.150.151.152.153.155.156.157.158.159.170.171.172.173.175.176.177.178.180.181.182.183.184.185.186.187.188.189.191.193.195.196.197.198.199".split(".")) + String(o(1e7, 99999999));
}
function d() {
	return `${`user${o(100, 99999)}_${Date.now().toString(36).slice(-4)}`}@${s([
		"qq.com",
		"163.com",
		"gmail.com",
		"outlook.com",
		"126.com",
		"sina.com",
		"foxmail.com"
	])}`;
}
function f() {
	let e = [
		"110101",
		"110105",
		"310101",
		"310115",
		"440106",
		"440305",
		"330102",
		"510104",
		"320102",
		"420106"
	], t = o(1965, 2003), n = String(o(1, 12)).padStart(2, "0"), r = String(o(1, 28)).padStart(2, "0"), i = String(o(100, 999)), a = [
		7,
		9,
		10,
		5,
		8,
		4,
		2,
		1,
		6,
		3,
		7,
		9,
		10,
		5,
		8,
		4,
		2
	], c = [
		"1",
		"0",
		"X",
		"9",
		"8",
		"7",
		"6",
		"5",
		"4",
		"3",
		"2"
	], l = `${s(e)}${t}${n}${r}${i}`, u = 0;
	for (let e = 0; e < 17; e++) u += parseInt(l[e]) * a[e];
	return l + c[u % 11];
}
function p() {
	return `${s([
		"北京市朝阳区",
		"北京市海淀区",
		"上海市浦东新区",
		"上海市黄浦区",
		"广州市天河区",
		"广州市越秀区",
		"深圳市南山区",
		"深圳市福田区",
		"杭州市西湖区",
		"杭州市滨江区",
		"成都市武侯区",
		"南京市鼓楼区",
		"武汉市洪山区",
		"西安市雁塔区",
		"苏州市工业园区",
		"重庆市渝中区"
	])}${s([
		"中关村大街",
		"南京西路",
		"天河路",
		"科技园路",
		"文三路",
		"解放路",
		"人民路",
		"建设大道",
		"长安街",
		"和平路",
		"中山路",
		"新华路",
		"光华大道",
		"未来科技城",
		"创业大道"
	])}${o(1, 999)}号`;
}
function m() {
	let e = /* @__PURE__ */ new Date();
	return e.setDate(e.getDate() + o(-90, 90)), c(e);
}
function h() {
	let e = /* @__PURE__ */ new Date();
	return e.setDate(e.getDate() + o(1, 10)), c(e);
}
function g(e = "") {
	let t = /* @__PURE__ */ new Date();
	t.setHours(12, 0, 0, 0);
	let n = /需晚于|不得早于|不能早于昨天|名单包|计划.*晚于|重复析出|单次型/i.test(e), r = 1;
	n && (r = 2);
	let i = r + (n ? 12 : 6);
	t.setDate(t.getDate() + o(r, i));
	let a = s([0, 30]);
	return t.setHours(o(10, 17), a, 0, 0), `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")} ${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}:${String(t.getSeconds()).padStart(2, "0")}`;
}
function _() {
	let e = o(10, 17), t = s([0, 30]);
	return `${String(e).padStart(2, "0")}:${String(t).padStart(2, "0")}:00`;
}
function v(e) {
	return /需晚于|不得早于|不能早于|昨天|前天|名单包|计划.*时间|执行时间|生效时间|disabledDate|不可选.*过去/i.test(e);
}
function y() {
	return `${s([
		"鼎信",
		"华创",
		"中联",
		"信达",
		"恒通",
		"远大",
		"盛世",
		"天宇",
		"博瑞",
		"启明",
		"汇智",
		"融信",
		"泰和",
		"新锐",
		"众合",
		"嘉禾",
		"瑞达",
		"宏图",
		"创联",
		"智远",
		"天成",
		"金源",
		"利达",
		"恒丰"
	])}${s([
		"科技",
		"信息",
		"网络",
		"数据",
		"金融",
		"商务",
		"传媒",
		"咨询",
		"服务",
		"贸易"
	])}${s([
		"有限公司",
		"股份有限公司",
		"集团",
		"有限责任公司"
	])}`;
}
function b() {
	let e = Date.now().toString(36).toUpperCase().slice(-3), t = "";
	for (let e = 0; e < 2; e++) t += "ABCDEFGHJKLMNPQRSTUVWXYZ"[o(0, 23)];
	return t += e, t += String(o(10, 99)), t;
}
function x(e) {
	return `${e}_${Date.now().toString(36).slice(-4)}_${o(100, 999)}`;
}
function S(e) {
	let t = e.replace(/\s+/g, "");
	for (let e of [
		/不超过(\d{1,4})个?字符/,
		/至多(\d{1,4})个?字符/,
		/最多(\d{1,4})个?字符/,
		/不大于(\d{1,4})个?字符/,
		/长度不超过(\d{1,4})/,
		/最长(\d{1,4})个?字符/,
		/≤\s*(\d{1,4})\s*个?字符/
	]) {
		let n = t.match(e);
		if (n) return Number(n[1]);
	}
}
function C(e) {
	return [
		e.validationError,
		e.ruleHints,
		e.extra,
		e.placeholder
	].filter(Boolean).join(" ");
}
function w(e) {
	return [...new Set([...e])].join("");
}
function T(e) {
	if (/\\p{|\\u{|\\[dDsSwW]|\(\?/.test(e)) return null;
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		if (r === "\\" && n + 1 < e.length) {
			let r = e[++n];
			r === "d" ? t.push(..."0123456789") : r === "n" ? t.push("\n") : r === "t" ? t.push("	") : r === "r" ? t.push("\r") : t.push(r);
			continue;
		}
		if (n + 2 < e.length && e[n + 1] === "-" && e[n + 2] !== "]") {
			let r = e.charCodeAt(n), i = e.charCodeAt(n + 2);
			if (r <= i && i - r < 2e3) {
				for (let e = r; e <= i; e++) {
					if (e >= 19968 && e <= 40959) return null;
					t.push(String.fromCodePoint(e));
				}
				n += 2;
				continue;
			}
		}
		let i = r.codePointAt(0);
		if (i >= 19968 && i <= 40959) return null;
		t.push(r);
	}
	let n = w(t.join(""));
	return n.length > 0 ? n : null;
}
function E(e) {
	if (!e?.trim()) return null;
	let t = e.trim(), n = t.match(/^\^\[([\s\S]+?)\]\+\$$/) || t.match(/^\^\[([\s\S]+?)\]\*$$/) || t.match(/^\^\[([\s\S]+?)\]\?$$/) || t.match(/^\^\[([\s\S]+?)\]$$/);
	if (n ||= t.match(/^\[([^\]]+)\](?:\+|\*|\?)?$/), !n) return null;
	let r = n[1];
	return /\[[\s\S]*\[/.test(r) || /\|/.test(r) ? null : T(r);
}
function D(e) {
	let t = e.match(/(?:只能包含|仅允许包含|只允许输入)([^。；;\r\n]+)/);
	if (!t) return null;
	let n = t[1].trim().replace(/等[^。；;]*$/, "").replace(/不允许.*$/, "").replace(/不可.*$/, "");
	n = n.replace(/\s+/g, "");
	let r = n.split(/[,，、]/).map((e) => e.trim()).filter(Boolean), i = [];
	for (let e of r) e.includes("及") ? i.push(...e.split("及").map((e) => e.trim()).filter(Boolean)) : i.push(e);
	let a = "";
	for (let e of i) if (e) if (/^字母$|^英文字母$/i.test(e) || /^大小写字母$/i.test(e)) a += "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	else if (/^数字$|^阿拉伯数字$/i.test(e)) a += "0123456789";
	else if (e === "＆" || e === "&") a += "&";
	else if (e === "＝" || e === "=") a += "=";
	else if (e === "-" || e === "－" || /^横线$|^连字符$|^减号$/i.test(e)) a += "-";
	else if (e === "_" || /^下划线$/i.test(e)) a += "_";
	else if (e === ".") a += ".";
	else if (e === " ") a += " ";
	else if (/字母.*数字|数字.*字母/.test(e) && e.length <= 16) a += "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	else if (/[\u4e00-\u9fff]{2,}/.test(e)) return null;
	else if (e.length === 1 && e.charCodeAt(0) < 128) a += e;
	else return null;
	return a.length > 0 ? w(a) : null;
}
function O(e, t) {
	let n = Math.max(2, Math.min(t, 100)), r = Math.max(2, Math.min(32, n)), i = o(Math.min(4, r), r), a = "";
	for (let t = 0; t < i; t++) a += e[o(0, e.length - 1)];
	return a.slice(0, n);
}
function k(e) {
	let t = e.replace(/\s+/g, "");
	return /仅支持数字英文/.test(t) || /仅支持英文数字/.test(t) || /(仅|只)支持[0-9A-Za-z]/.test(t) || /数字和?英文/.test(t) || /英文和?数字/.test(t) || /字母或数字|数字或字母|字母和数字|字母与数字/.test(t) || /只能为?字母数字|只能输入字母数字|请输入字母数字/.test(t) || /alphanumeric/i.test(e);
}
function A(e) {
	let t = "";
	for (let n = 0; n < e; n++) t += "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[o(0, 31)];
	return t;
}
function j(e) {
	if (!e) return {};
	let t = e.replace(/\s+/g, " "), n = {}, r = t.match(/(\d+(?:\.\d+)?)\s*[-~～至]\s*(\d+(?:\.\d+)?)/);
	r && (n.min = Number(r[1]), n.max = Number(r[2]));
	for (let e of [/(?:不超过|不大于|至多|最多|≤|<=)\s*(\d+(?:\.\d+)?)/, /(\d+(?:\.\d+)?)\s*(?:以内|以下)/]) {
		let r = t.match(e);
		if (r) {
			n.max = Number(r[1]);
			break;
		}
	}
	for (let e of [/(?:不少于|不小于|至少|最少|≥|>=)\s*(\d+(?:\.\d+)?)/, /(\d+(?:\.\d+)?)\s*(?:以上|起)/]) {
		let r = t.match(e);
		if (r) {
			n.min = Number(r[1]);
			break;
		}
	}
	return /两位小数|保留两位|最多两位/.test(e) ? n.decimals = 2 : /一位小数|保留一位/.test(e) && (n.decimals = 1), /整数|必须为整|只能为整/.test(e) && n.decimals === void 0 && (n.decimals = 0), n;
}
function M(e, t) {
	let n = 1, r = 1e3;
	if (e?.min !== void 0 && (n = e.min), e?.max !== void 0 && (r = e.max), t.min !== void 0 && (n = Math.max(n, t.min)), t.max !== void 0 && (r = Math.min(r, t.max)), n > r) return e?.min !== void 0 && e?.max !== void 0 && e.min <= e.max ? {
		min: e.min,
		max: e.max,
		decimals: t.decimals ?? 0
	} : {
		min: 1,
		max: 1e3,
		decimals: t.decimals ?? 0
	};
	let i = t.decimals ?? 0;
	return {
		min: n,
		max: r,
		decimals: i
	};
}
function N(e) {
	let t = j(e.extra), { min: n, max: r, decimals: i } = M(e.constraints, t);
	return i > 0 ? (n + Math.random() * (r - n)).toFixed(i) : String(o(Math.ceil(n), Math.floor(r)));
}
function P() {
	let e = /* @__PURE__ */ new Date();
	e.setDate(e.getDate() + o(-30, 30));
	let t = new Date(e);
	t.setDate(t.getDate() + o(1, 60));
	let n = () => {
		let e = String(o(10, 17)).padStart(2, "0"), t = s([0, 30]);
		return `${e}:${String(t).padStart(2, "0")}:00`;
	};
	return `${c(e)} ${n()},${c(t)} ${n()}`;
}
var F = [
	[/开始时间|结束时间|截止时间|到期时间/i, h],
	[/手机|电话|座机|联系方式|tel|phone/i, u],
	[/姓名|联系人|用户名|客户名|处理人/i, l],
	[/邮箱|email|邮件/i, d],
	[/身份证|证件号/i, f],
	[/地址|住址|详细地址/i, p],
	[/编号|编码|代码|码值|条码|二维码|邀请码|兑换码|验证码|取件码|渠道码|code|id|号/i, b],
	[/公司|企业|单位|机构/i, y],
	[/日期|时间|date/i, m],
	[/备注|说明|描述|原因|详情/i, () => x("测试备注")],
	[/金额|价格|费用|amount/i, () => String(o(100, 99999))],
	[/数量|件数|个数|count|num/i, () => String(o(1, 500))],
	[/比例|百分比|占比/i, () => String(o(1, 100))],
	[/年龄/i, () => String(o(18, 65))],
	[/密码|password/i, () => `Pwd${o(1e4, 99999)}!`],
	[/名称|名字/i, () => o(0, 1) ? y() : l()]
];
function I(e) {
	let t = {};
	for (let n of e) {
		let e = C(n);
		if (n.type === "input" || n.type === "textarea") {
			let r = E(n.constraints?.pattern), i = D(e), a = (r && r.length > 0 ? r : null) ?? (i && i.length > 0 ? i : null);
			if (a) {
				let r = n.constraints?.maxLength ?? S(e) ?? 100, i = Math.max(2, Math.min(r, 100));
				t[n.id] = O(a, i);
				continue;
			}
			if (k(e)) {
				let r = n.constraints?.maxLength ?? S(e), i = r === void 0 ? 8 : Math.max(1, Math.min(r, 32));
				t[n.id] = A(i);
				continue;
			}
		}
		if (n.type === "select" || n.type === "cascader" || n.type === "treeselect" || n.type === "transfer") {
			t[n.id] = n.options && n.options.length > 0 ? s(n.options) : "random";
			continue;
		}
		if (n.options && n.options.length > 0) {
			t[n.id] = s(n.options);
			continue;
		}
		if (n.type === "daterange") {
			t[n.id] = P();
			continue;
		}
		if (n.type === "number") {
			t[n.id] = N(n);
			continue;
		}
		if (n.type === "time") {
			t[n.id] = _();
			continue;
		}
		if (n.type === "date" && (/执行时间|生效时间|触发时间|运行时间|定时(?!器)/i.test(n.label) || v(e))) {
			t[n.id] = g(e);
			continue;
		}
		let r = F.find(([e]) => e.test(n.label));
		if (r) {
			t[n.id] = r[1]();
			continue;
		}
		switch (n.type) {
			case "input":
				t[n.id] = x("测试");
				break;
			case "textarea":
				t[n.id] = x("这是自动生成的测试数据");
				break;
			case "date":
				t[n.id] = v(e) ? g(e) : m();
				break;
			case "checkbox":
				t[n.id] = "true";
				break;
			case "switch":
				t[n.id] = o(0, 1) ? "true" : "false";
				break;
			default: break;
		}
		let i = t[n.id], a = n.constraints?.maxLength;
		typeof i == "string" && a !== void 0 && a > 0 && i.length > a && (t[n.id] = i.slice(0, a));
	}
	return console.log("[AI Form Copilot] 生成 Mock 数据:", JSON.stringify(t)), t;
}
//#endregion
//#region src/background/index.ts
async function L() {
	let [e] = await chrome.tabs.query({
		active: !0,
		currentWindow: !0
	});
	if (!e?.id) throw Error("无法获取当前标签页");
	return e;
}
async function R(e, t) {
	try {
		return await chrome.tabs.sendMessage(e, t);
	} catch (n) {
		console.warn("[AI Form Copilot] Background -> Content 消息失败，尝试注入 content.js 后重试:", {
			tabId: e,
			messageType: t?.type,
			error: n
		}), await chrome.scripting.executeScript({
			target: { tabId: e },
			files: ["content.js"]
		}), await new Promise((e) => setTimeout(e, 300));
		try {
			return await chrome.tabs.sendMessage(e, t);
		} catch (n) {
			throw console.error("[AI Form Copilot] Background -> Content 重试仍失败:", {
				tabId: e,
				messageType: t?.type,
				error: n
			}), n;
		}
	}
}
chrome.runtime.onMessage.addListener((t, n, r) => ((async () => {
	try {
		switch (t.type) {
			case e.SCAN_FORM: {
				let t = await R((await L()).id, { type: e.SCAN_FORM });
				r({
					type: e.SCAN_RESULT,
					fields: t.fields
				});
				break;
			}
			case e.GENERATE_DATA: {
				let { fields: n, aiConfig: i } = t, o = i.apiKey ? await a(n, i) : I(n);
				r({
					type: e.GENERATE_RESULT,
					data: o
				});
				break;
			}
			case e.FILL_FORM:
				r(await R((await L()).id, t));
				break;
			default: r({
				type: e.ERROR,
				error: "未知消息类型"
			});
		}
	} catch (n) {
		console.error("[AI Form Copilot] Background error:", {
			messageType: t?.type,
			error: n
		}), r({
			type: e.ERROR,
			error: n instanceof Error ? n.message : String(n)
		});
	}
})(), !0)), console.log("[AI Form Copilot] Background service worker loaded");
//#endregion
